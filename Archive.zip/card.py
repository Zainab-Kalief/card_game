class Card(object):
    def __init__(self, suit, rank, value):
        self.suit = suit
        self.rank = rank
        self.value = value
